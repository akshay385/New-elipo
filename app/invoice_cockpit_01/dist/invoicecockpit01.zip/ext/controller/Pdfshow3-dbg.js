sap.ui.define([
    "sap/m/MessageToast"
], function(MessageToast) {
    'use strict';

    return {
        pdfshowfunc: function(oEvent) {
            this.showSideContent("form");
        }
    };
});
